import React from 'react'

const LogoutScreen = () => {  
  return (
    <div>LogoutScreen</div>
  )
}

export default LogoutScreen