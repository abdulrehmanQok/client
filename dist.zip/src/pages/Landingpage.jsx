import React from 'react';

const Landingpage = () => {
  return (
    <>
      {/* Hero Section for Fragstalk.pk */}
      <section className="relative bg-gradient-to-r from-purple-900 via-indigo-800 to-pink-700 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-60 bg-[url('/image/fragrance-background.jpg')] bg-cover bg-center z-0"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60 z-10"></div> {/* Adds depth with black overlay */}
        <div className="container mx-auto flex px-5 py-24 md:flex-row flex-col items-center relative z-20">
          <div className="lg:flex-grow md:w-1/2 lg:pr-24 md:pr-16 flex flex-col md:items-start md:text-left mb-16 md:mb-0 items-center text-center">
            <h1 className="title-font sm:text-8xl text-6xl font-extrabold leading-tight mb-4 tracking-wide text-shadow-lg animate-fadeInUp">
              Welcome to <span className="text-gold">Fragstalk.pk</span>
              <br className="hidden lg:inline-block" />
              Discover Your Signature Scent
            </h1>
            <p className="mb-8 text-xl leading-relaxed text-shadow-md animate-fadeInUp delay-1">
              At Fragstalk.pk, we bring you the finest selection of perfumes and fragrances crafted to suit your unique style and personality. Explore our curated collection and indulge in a world of luxury scents.
            </p>
            <div className="flex justify-center animate-fadeInUp delay-2">
              <button className="inline-flex text-white bg-purple-600 border-0 py-4 px-8 focus:outline-none hover:bg-purple-700 rounded-full text-lg transition-transform transform hover:scale-110 shadow-xl">
                Shop Fragrances
              </button>
              <button className="ml-4 inline-flex text-purple-600 bg-white border-0 py-4 px-8 focus:outline-none hover:bg-gray-100 rounded-full text-lg transition-transform transform hover:scale-110 shadow-xl">
                View Collections
              </button>
            </div>
          </div>
          <div className="lg:max-w-lg lg:w-full md:w-1/2 w-5/6 animate-fadeInRight delay-2">
            <img
              className="object-cover object-center rounded-lg shadow-2xl"
              alt="Fragstalk.pk Hero"
              src="/image/fragrance-bottle.jpg"
            />
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="text-gray-700 bg-white">
        <div className="container px-5 py-24 mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold">Featured Fragrances</h2>
            <p className="text-base leading-relaxed text-gray-600">Handpicked fragrances, just for you.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Product Cards */}
            {[
              { name: 'Rasasi Hawas', price: '10000', imgSrc: 'public/image/hawas.jpg' },
              { name: 'Lattafa Mahir Legacy', price: '5500', imgSrc: 'public/image/legacy.jpg' },
              { name: 'Creed Aventus', price: '169000', imgSrc: 'public/image/aventus.jpg' },
              { name: 'Amber Luxe', price: '120.00', imgSrc: '/image/amber-fragrance.jpg' },
            ].map((product, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg p-6 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img
                  alt={product.name}
                  className="object-cover object-center w-full h-48 mb-4 rounded-lg"
                  src={product.imgSrc}
                />
                <div className="text-center">
                  <h3 className="text-gray-500 text-xs tracking-widest mb-1">FRAGRANCE</h3>
                  <h2 className="text-lg font-medium text-gray-900">{product.name}</h2>
                  <p className="mt-1">Rs{product.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Promotional Section */}
      <section className="relative bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-500 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30 bg-[url('/image/fragrance-promo.jpg')] bg-cover bg-center z-0"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black opacity-40 z-10"></div>
        <div className="container mx-auto py-24 px-5 relative z-20 text-center">
          <h2 className="text-5xl font-extrabold mb-6 leading-tight tracking-tight">
            Limited Time Offers
          </h2>
          <p className="mb-8 text-lg leading-relaxed max-w-xl mx-auto">
            Indulge in our exclusive discounts of up to 50% off on selected fragrances. Enhance your collection with luxury scents at unbeatable prices.
          </p>
          <button className="bg-white text-purple-700 px-8 py-4 rounded-full font-semibold text-lg hover:bg-purple-100 transition-transform transform hover:scale-110 shadow-lg">
            Shop Discounts
          </button>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-gradient-to-r from-gray-100 via-gray-200 to-gray-300 py-24">
        <div className="container mx-auto px-5">
          <div className="text-center mb-12">
            <h2 className="text-5xl font-extrabold text-gray-900 mb-4">What Our Customers Are Saying</h2>
            <p className="text-xl text-gray-700 max-w-xl mx-auto">
              Hear from our delighted customers who have found their signature scents at Fragstalk.pk.
            </p>
          </div>
          <div className="flex flex-wrap -m-4">
            {/* Testimonial Cards */}
            {[
              {
                name: 'Sarah Ahmed',
                testimonial: "Fragstalk.pk helped me find the perfect perfume. The quality and variety are amazing!",
                image: '/image/customer1.jpg'
              },
              {
                name: 'Hassan Ali',
                testimonial: "I love the scents I purchased. Great customer service and fast delivery!",
                image: '/image/customer2.jpg'
              }
            ].map((customer, index) => (
              <div key={index} className="p-4 md:w-1/2 w-full">
                <div className="h-full bg-white p-8 rounded-lg shadow-lg transition-transform transform hover:scale-105 hover:shadow-2xl">
                  <p className="leading-relaxed mb-6 text-gray-800 italic">
                    "{customer.testimonial}"
                  </p>
                  <div className="flex items-center">
                    <img
                      alt={customer.name}
                      src={customer.image}
                      className="w-16 h-16 rounded-full object-cover border-4 border-gradient-to-r from-purple-400 via-teal-400 to-green-400"
                    />
                    <div className="pl-4">
                      <span className="font-semibold text-gray-900 text-lg">{customer.name}</span>
                      <p className="text-gray-600 text-sm mt-1">Verified Buyer</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="relative bg-gradient-to-r from-purple-500 via-teal-500 to-blue-700 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30 bg-[url('/image/fragrance-cta.jpg')] bg-cover bg-center z-0"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black opacity-50 z-10"></div>
        <div className="container mx-auto py-24 px-5 relative z-20 text-center">
          <h2 className="text-5xl font-extrabold mb-6 leading-tight tracking-tight">
            Join the Fragstalk.pk Club
          </h2>
          <p className="mb-8 text-lg leading-relaxed max-w-lg mx-auto">
            Sign up today and get access to exclusive offers, early product releases, and much more. Become a part of the Fragstalk.pk fragrance community!
          </p>
          <button className="bg-white text-purple-700 px-8 py-4 rounded-full font-semibold text-lg hover:bg-gray-200 transition-transform transform hover:scale-105 shadow-lg">
            Sign Up Now
          </button>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="bg-gray-900 text-white">
        <div className="container mx-auto py-12 px-5 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-sm text-gray-400">© 2024 Fragstalk.pk. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0">
            <a href="#" className="text-gray-400 hover:text-white">Facebook</a>
            <a href="#" className="text-gray-400 hover:text-white">Instagram</a>
            <a href="#" className="text-gray-400 hover:text-white">Twitter</a>
            <a href="#" className="text-gray-400 hover:text-white">LinkedIn</a>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Landingpage;
